If you open the project by draggin the file, source files might not be recognized.

Solution:
File> Project Structure > Modules
Click the directory and click the sources button.

https://stackoverflow.com/questions/4904052/what-does-this-symbol-mean-in-intellij-red-circle-on-bottom-left-corner-of-fil

It works fine when imported.